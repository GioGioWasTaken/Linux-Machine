
#ifndef SECOND_PASS_H
#define SECOND_PASS_H

#include <stdio.h>
#include "first_pass.h"
#include "../Headers/symbols.h"
#include <string.h>
#include <time.h>

#endif
